def bowling(nums: list[int]) -> int:
    # TODO
    # Remove the following return statement, and
    # write your own solution.
    return 0

if __name__ == "__main__":
    nums = [-3,1,1,9,9,2,-5,-5]
    out = bowling(nums)
    print(out)
