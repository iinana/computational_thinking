def robot(grid: list[list[int]]) -> list[tuple]:
  # TODO
  # Remove the following return statement, and
  # write your own solution.
  return 0

if __name__ == "__main__":
    # Example 1
    grid = [[0, 0, 1, 1],
            [1, 0, 0, 1],
            [0, 0, 1, 1],
            [0, 1, 1, 1],
            [0, 0, 0, 0]]
    print("Example 1:", grid)
    path = robot(grid)
    print("Path:", path)

    # Example 2
    grid = [[0, 0, 1, 1],
            [1, 0, 1, 1],
            [0, 0, 0, 0],
            [0, 1, 1, 0],
            [0, 0, 0, 0]]
    print("Example 2:", grid)
    path = robot(grid)
    print("Path:", path)

