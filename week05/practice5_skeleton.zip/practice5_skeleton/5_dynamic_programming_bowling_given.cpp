#include <iostream>
#include <vector>
#include <algorithm>
#include <climits>

using namespace std;
int bowling(vector<int>& nums) {

    // TODO    

}

int main() {
    vector<int> nums = {-3, 1, 1, 9, 9, 2, -5, -5};

    int out = bowling(nums);
    cout << "Result from bowling function: " << out << endl;

    return 0;
}

