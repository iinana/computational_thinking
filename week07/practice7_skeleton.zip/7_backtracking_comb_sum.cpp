#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

vector<vector<int>> combination_sum(vector<int>& candidates, int target) {
    //TODO
}

int main() {
    // Example 1
    vector<int> candidates1 = {10, 1, 2, 7, 6, 1, 5};
    int target1 = 8;
    cout << "Example 1" << endl;
    cout << "candidates: ";
    sort(candidates1.begin(), candidates1.end());
    for (int i = 0; i < candidates1.size(); i++) {
        cout << candidates1[i];
        if (i < candidates1.size() - 1)
            cout << ", ";
    }
    cout << endl;
    cout << "target: " << target1 << endl;
    vector<vector<int>> ans1 = combination_sum(candidates1, target1);
    cout << "ans: ";
    print_answers(ans1);
    cout << "**************************************************" << endl;

    // Example 2
    vector<int> candidates2 = {2, 5, 2, 1, 2};
    int target2 = 5;
    cout << "Example 2" << endl;
    cout << "candidates: ";
    sort(candidates2.begin(), candidates2.end());
    for (int i = 0; i < candidates2.size(); i++) {
        cout << candidates2[i];
        if (i < candidates2.size() - 1)
            cout << ", ";
    }
    cout << endl;
    cout << "target: " << target2 << endl;
    vector<vector<int>> ans2 = combination_sum(candidates2, target2);
    cout << "ans: ";
    print_answers(ans2);
    
    return 0;
}

