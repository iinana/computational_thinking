// itinerary.cpp
#include <iostream>
#include <vector>
#include <string>
#include <unordered_map>
#include <set>
#include <algorithm>

using namespace std;

void dfs(const string& airport,
         unordered_map<string, multiset<string>>& flight_map,
         vector<string>& path);

vector<string> itinerary(vector<pair<string, string>>& flights, string& start) {
    unordered_map<string, multiset<string>> flight_map;
    for (auto& flight : flights) {
    //TODO
}

void dfs(const string& airport,
         unordered_map<string, multiset<string>>& flight_map,
         vector<string>& path) {
    //TODO
}

int main() {
    vector<pair<string, string>> flights = {
        {"SFO", "HKO"},
        {"YYZ", "SFO"},
        {"YUL", "YYZ"},
        {"HKO", "ORD"}
    };
    string start = "YUL";
    vector<string> result = itinerary(flights, start);
    if (!result.empty()) {
        for (const auto& airport : result) {
            cout << airport << " ";
        }
        cout << endl;  // Expected Output: YUL YYZ SFO HKO ORD
    } else {
        cout << "None" << endl;
    }

    flights = {
        {"SFO", "COM"},
        {"COM", "YYZ"}
    };
    start = "COM";
    result = itinerary(flights, start);
    if (!result.empty()) {
        for (const auto& airport : result) {
            cout << airport << " ";
        }
        cout << endl;  // Expected Output: None
    } else {
        cout << "None" << endl;
    }

    return 0;
}

