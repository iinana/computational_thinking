from typing import List

def combination_sum(candidates: List[int], target: int) -> List[List[int]]:
  # TODO
  # Remove the following return statement, and
  # write your own solution.
  return 0

if __name__ == '__main__':
    candidates = [10, 1, 2, 7, 6, 1, 5]
    target = 8
    ans = combination_sum(candidates, target)
    print("Example 1")
    print(f"candidates: {candidates}")
    print(f"target: {target}")
    print(f"ans: {ans}")
    print("*"*50)
    print("Example 2")
    candidates = [2, 5, 2, 1, 2]
    target = 5
    ans = combination_sum(candidates, target)
    print(f"candidates: {candidates}")
    print(f"target: {target}")
    print(f"ans: {ans}")
