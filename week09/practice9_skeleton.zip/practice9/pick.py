import random

def pick(nums, target):
  # TODO
  # Remove the following return statement, and
  # write your own solution.
  return 0

if __name__ == '__main__':
  nums = [1,2,3,3,3]
  target = 1
  output = pick(nums, target)
  print(output) # The output for the above example is 0.