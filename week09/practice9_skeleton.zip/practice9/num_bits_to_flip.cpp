#include <iostream>
using namespace std;

int num_bits_to_flip(int a, int b) {
    // TODO
    // Remove the following return statement, and
    // write your own solution.
    return 0;
}

int main() {
    int a = 29;
    int b = 15;

    int output = num_bits_to_flip(a, b);
    cout << output << endl;
    
    return 0;
    // The output for the above example is 2.
}
