def num_bits_to_flip(a, b):
  # TODO
  # Remove the following return statement, and
  # write your own solution.
  return 0

if __name__ == '__main__':
  a = 29
  b = 15
  output = num_bits_to_flip(a, b)
  print(output) # The output for the above example is 2.
